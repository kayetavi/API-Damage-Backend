module.exports = {
    mongoURI: "",
    secretOrKey: "secret"
};
